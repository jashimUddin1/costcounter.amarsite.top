
<!-- dashboard/layout/top_header.php -->
<div class="card shadow p-0 fixed-top">
    <div class="card-header  bg-dark text-white">
        <div class="container d-flex justify-content-between">
            <h5 class="mb-0">📊 ড্যাশবোর্ড</h5>
        <a href="../index.php?year=<?= $year ?>&month=<?= htmlspecialchars($month) ?>" class="btn btn-light btn-sm"> Home</a>
        </div>
    </div>
</div>