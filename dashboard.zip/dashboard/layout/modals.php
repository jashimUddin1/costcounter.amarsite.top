<!-- Axis Full View Modal -->
<div class="modal fade" id="axisFullView" tabindex="-1">
  <div class="modal-dialog modal-xl modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">
          <?= $is_all_month ? '📅 প্রতিমাসের খরচ (Full View)' : '📅 প্রতিদিনের খরচ (Full View)' ?> -
          <?= $is_all_month ? "সকল মাস {$year_bn}" : "{$month_label} {$year_bn}" ?>
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <canvas id="axisChartFull" style="min-height:400px"></canvas>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Category Full View Modal -->
<div class="modal fade" id="categoryFullView" tabindex="-1">
  <div class="modal-dialog modal-xl modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">
          🧾 ক্যাটেগরি ভিত্তিক খরচ (Full View) -
          <?= $is_all_month ? "সকল মাস {$year_bn}" : "{$month_label} {$year_bn}" ?>
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <canvas id="categoryChartFull" style="min-height:400px"></canvas>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
