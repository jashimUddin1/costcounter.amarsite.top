// Axis Chart (Main)
(function () {
  const el = document.getElementById('axisChart');
  if (!el) return;
  new Chart(el.getContext('2d'), {
    type: 'bar',
    data: {
      labels: axisLabels,
      datasets: [{
        label: axisLabelTitle,
        data: axisData,
        borderWidth: 1,
        backgroundColor: 'rgba(54,162,235,0.5)',
        borderColor: 'rgba(54,162,235,1)'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: { y: { beginAtZero: true } }
    }
  });
})();

// Axis Chart (Full)
(function () {
  const el = document.getElementById('axisChartFull');
  if (!el) return;
  new Chart(el.getContext('2d'), {
    type: 'bar',
    data: {
      labels: axisLabels,
      datasets: [{
        label: axisLabelTitle,
        data: axisData,
        borderWidth: 1,
        backgroundColor: 'rgba(54,162,235,0.5)',
        borderColor: 'rgba(54,162,235,1)'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: { y: { beginAtZero: true } }
    }
  });
})();

// Category Chart (Main)
(function () {
  const el = document.getElementById('categoryChart');
  if (!el) return;
  const ctx = el.getContext('2d');

  new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: categoryLabels,
      datasets: [{
        label: 'টাকা',
        data: categoryData,
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'left',
          align: 'start',
          labels: {
            generateLabels: function (chart) {
              const dataset = chart.data.datasets[0];
              const total = dataset.data.reduce((a, b) => a + b, 0);
              return chart.data.labels.map((label, i) => {
                const value = dataset.data[i];
                const percentage = total ? ((value / total) * 100).toFixed(1) : 0;
                return {
                  text: `${label}  ${percentage}%`,
                  fillStyle: dataset.backgroundColor ? dataset.backgroundColor[i] : undefined,
                  index: i
                };
              });
            }
          }
        }
      }
    }
  });
})();

// Category Chart (Full)
(function () {
  const el = document.getElementById('categoryChartFull');
  if (!el) return;
  const ctx = el.getContext('2d');

  new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: categoryLabels,
      datasets: [{
        label: 'টাকা',
        data: categoryData,
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'left',
          align: 'start',
          labels: {
            generateLabels: function (chart) {
              const dataset = chart.data.datasets[0];
              const total = dataset.data.reduce((a, b) => a + b, 0);
              return chart.data.labels.map((label, i) => {
                const value = dataset.data[i];
                const percentage = total ? ((value / total) * 100).toFixed(1) : 0;
                return {
                  text: `${label} - ${percentage}% (${value.toLocaleString()} টাকা)`,
                  fillStyle: dataset.backgroundColor ? dataset.backgroundColor[i] : undefined,
                  index: i
                };
              });
            }
          }
        }
      }
    }
  });
})();
